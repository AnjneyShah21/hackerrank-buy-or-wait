import sys
from pathlib import Path

root_dir = Path(__file__).resolve().parent
code_dir = root_dir / 'code'

if str(root_dir) not in sys.path:
    sys.path.insert(0, str(root_dir))
if str(code_dir) not in sys.path:
    sys.path.insert(0, str(code_dir))

from code.main import main

if __name__ == '__main__':
    main()
